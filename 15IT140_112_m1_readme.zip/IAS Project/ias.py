import subprocess
import os

os.chdir("/media/manohar/Rudresh's EHD/IAS Project/malware1")
with open('filenames.txt','r') as names:
	i=1
	for line in names:
		print " Analysis for the file",line[:-1],i
		output = subprocess.check_output("strings "+line[:-1], shell=True)
		with open( 'answer.csv', 'a' ) as f:

			#f = open('answer.txt', 'r')
			a=1
			if "GetProcAddress" not in output: 
			    a=0

			f.write(str(a))
			f.write(" ")
			a=1
			if "RegQueryValueExW" not in output: 
			    a=0
			f.write(str(a))
			f.write(" ")
			a=1
			if "CreateFileW" not in output: 
			    a=0

			f.write(str(a))
			f.write(" ")
			a=1
			if "OpenFile" not in output: 
			    a=0

			f.write(str(a))
			f.write(" ")
			a=1
			if "FindFirstFileA" not in output: 
			    a=0

			f.write(str(a))
			f.write(" ")
			a=1
			if "FindNextFileA" not in output: 
			    a=0

			f.write(str(a))
			f.write(" ")
			a=1
			if "CopyMemory" not in output: 
			    a=0

			f.write(str(a))
			f.write(" ")
			f.write('\n')
		print "writing to the file done"
		i=i+1	
